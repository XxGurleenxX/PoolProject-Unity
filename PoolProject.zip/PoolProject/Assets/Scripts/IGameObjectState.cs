public interface IGameObjectState {
	void Update();
	void FixedUpdate();
	void LateUpdate();
}